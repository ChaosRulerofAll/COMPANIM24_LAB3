This is a Godot file, not a Unity file.
Consequently, I couldn't use any of the assets or code given to me and had to make my own.
So there's no graphical assets, sorry, but all the code is original writen by me.
